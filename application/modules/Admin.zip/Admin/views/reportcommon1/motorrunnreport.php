<div  class="text-head"> Motor Running Hours Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
						<thead>
							<tr style="font-weight: bold;"> 
							<th rowspan='2' align='center'>SNo</th>
							<th rowspan='2' align='center'>Date</th>
							<th rowspan='2' align='center'>Floor</th>    
							<th colspan='4' align='center'>Motors</th> 
							</tr>
							
							<tr style="font-weight: bold;">
							<td>Motor 01</td><td>Motor 02</td><td>Motor 03</td><td>Motor 04</td>							
							</tr>
														<tr>
							<td align='center'>1</td>
							<td align='center'>2020-11-01</td>
							<td align='center'>Floor1</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
							<tr>
							<td align='center'>2</td>
							<td align='center'>2020-11-02</td>
							<td align='center'>Floor1</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
							<tr>
							<td align='center'>3</td>
							<td align='center'>2020-11-03</td>
							<td align='center'>Floor1</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
							<tr>
							<td align='center'>4</td>
							<td align='center'>2020-11-04</td>
							<td align='center'>Floor1</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
							<tr>
							<td align='center'>5</td>
							<td align='center'>2020-11-05</td>
							<td align='center'>Floor1</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
							<tr>
							<td align='center'>6</td>
							<td align='center'>2020-11-06</td>
							<td align='center'>Floor1</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
						</thead>
						<tbody>
							
							
						</tbody>
					</table>