<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="icon" type="image/png" href="<?php echo base_url(); ?>asset/spinfocityasset/Images/Web-Icon.png" />
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/AdminLTE.min.css">
 
    <link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/_all-skins.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/skin-blue.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/select2.min.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>asset/admin/css/stylesheet.css"/>
<style>
.seach-button{margin-top:25px;}
.required_fields{color:red}
</style>