<div  class="text-head"> Status View Report</div>
<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
						<thead>
							<tr>
							<th rowspan='2' align='center'>SNo</th>
							<th rowspan='2' align='center'>Time</th>
							<th rowspan='2' align='center'>Floor</th>
							<th rowspan='2' align='center'>FirePump</th>
							<th colspan='8' align='center'>Meters</th>
							</tr>

							<tr >
							<th align='center' colspan='2'>Jockey Pump</th>
							<th align='center' colspan='2'>Sprinkler Pump</th>
							<th align='center' colspan='2'>Hydrant Pump</th>
							<th align='center' colspan='2'>Diesel Pump</th>

							</tr>

							<tr>
							<td align='center' rowspan='3'>1</td>
							<td align='center' rowspan='3'>00:00 To 01:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center'style="color: yellow">Manual</td>
                            <td align='center' >00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>2</td>
							<td align='center' rowspan='3'>01:00 To 02:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>3</td>
							<td align='center' rowspan='3'>02:00 To 03:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>4</td>
							<td align='center' rowspan='3'>03:00 To 04:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>5</td>
							<td align='center' rowspan='3'>04:00 To 05:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>6</td>
							<td align='center' rowspan='3'>05:00 To 06:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>7</td>
							<td align='center' rowspan='3'>06:00 To 07:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>8</td>
							<td align='center' rowspan='3'>07:00 To 08:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>9</td>
							<td align='center' rowspan='3'>08:00 To 09:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>10</td>
							<td align='center' rowspan='3'>09:00 To 10:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>11</td>
							<td align='center' rowspan='3'>10:00 To 11:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            <tr>
							<td align='center'rowspan='3'>12</td>
							<td align='center' rowspan='3'>11:00 To 12:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>13</td>
							<td align='center' rowspan='3'>12:00 To 13:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>14</td>
							<td align='center' rowspan='3'>13:00 To 14:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>15</td>
							<td align='center' rowspan='3'>14:00 To 15:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>16</td>
							<td align='center' rowspan='3'>15:00 To 16:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>17</td>
							<td align='center' rowspan='3'>16:00 To 17:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>18</td>
							<td align='center' rowspan='3'>17:00 To 18:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>19</td>
							<td align='center' rowspan='3'>18:00 To 19:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>20</td>
							<td align='center' rowspan='3'>19:00 To 20:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>21</td>
							<td align='center' rowspan='3'>20:00 To 21:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr><tr>
							<td align='center'rowspan='3'>22</td>
							<td align='center' rowspan='3'>21:00 To 22:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>23</td>
							<td align='center' rowspan='3'>22:00 To 23:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
							<tr>
							<td align='center'rowspan='3'>24</td>
							<td align='center' rowspan='3'>23:00 To 24:00</td>
							<td align='center' rowspan='3'>Floor1</td>
							<td align='center' rowspan='3'>Firepump</td>
							<td align='center' style="color: green">Auto</td>
							<td align='center'>00:55 Hrs</td>
							<td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>00:55 Hrs</td>
                            <td align='center' style="color: green">Auto</td>
                            <td align='center'>01:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: yellow">Manual</td>
							<td align='center'>00:00 Hrs</td>
							<td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>
                            <td align='center' style="color: yellow">Manual</td>
                            <td align='center'>00:00 Hrs</td>

							</tr>
                            <tr>

							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
							<td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>
                            <td align='center' style="color: red">Off</td>
							<td align='center'>00:05 Hrs</td>

							</tr>
                            </thead>
						<tbody>


						</tbody>
					</table>

</body>
</html>
