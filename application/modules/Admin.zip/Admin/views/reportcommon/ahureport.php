
<div class="text-head"> AHU Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
	<thead>
							<tr style="font-weight: bold;">
								<th class="text-center">Sno.</th>
								<th class="text-center">Floor</th>
								<th class="text-center">Meter</th>
								
												
							</tr>
						</thead>
					
					</table>