
<div class="AppFooter">
        <div class="AppVrsnDtls">
            <span class="AppCurrVrsn">Version:<span class="Vrsn">v3.0.20</span></span>
        </div>
        <div class="AppPwrdDtls">
            <span class="CorpTxt">Powered by<a href="#" class="Lnk" target="_blank">WIS</a></span>
        </div>
    </div>