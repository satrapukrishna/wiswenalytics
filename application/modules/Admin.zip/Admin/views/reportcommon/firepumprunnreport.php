<span class="SctnTtl">Firepump Running Hours Report</span>

<table class="RprtTbl">
						<thead>
							<tr > 
							<th rowspan='2' >SNo</th>
							<th rowspan='2' >Date</th>
							<th rowspan='2' >Floor</th>
							<th rowspan='2' >FirePump</th>    
							<th colspan='4' >Meters</th> 
							</tr>
							
							<tr >
							<th>Jockey Pump</th><th>Sprinkler Pump</th><th>Hydrant Pump</th><th>Diesel Pump</th>							
							</tr>
														<tr>
							<td >1</td>
							<td >2020-11-01</td>
							<td >Floor1</td>
							<td >Firepump</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
														<tr>
							<td >2</td>
							<td >2020-11-02</td>
							<td >Floor1</td>
							<td >Firepump</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
														<tr>
							<td >3</td>
							<td >2020-11-03</td>
							<td >Floor1</td>
							<td >Firepump</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
														<tr>
							<td >4</td>
							<td >2020-11-04</td>
							<td >Floor1</td>
							<td >Firepump</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
														<tr>
							<td >5</td>
							<td >2020-11-05</td>
							<td >Floor1</td>
							<td >Firepump</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
														<tr>
							<td >6</td>
							<td >2020-11-06</td>
							<td >Floor1</td>
							<td >Firepump</td>
								<td>0</td><td>0</td><td>0</td><td>0</td>							
							</tr>
						</thead>
						<tbody>
							
							
						</tbody>
					</table>