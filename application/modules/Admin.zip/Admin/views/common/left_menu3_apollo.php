<div id="DshbrdLft" class="DshBrdLnk">
            <div class="BrndHldr">
            
                <a href="<?php echo site_url('Admin/Home/aircondition_apollo')?>" ><span class="BrndNm"><?php echo $this->session->userdata('client_name')?></span></a>
            </div>
            <div class="DshBrdLnkCntr" id="root" data-simplebar>
                <ul class="LnkHldr FrstLvl">
                    
                    
                        
                                <li>
                                    <a class="Lnk Arr Slct" href="#" onclick="menushow(559)" id="cat558"><img src="<?php echo site_url() ?>asset/demoforall/Images/air_menu.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">AHU</span></a>
                                    <ul class="ScndLvl" id="subcat559" style="display: none;">
                                         
                                         <li>
                                            <a href="<?php echo site_url('Admin/Home/aircondition_apollo/')?>#tomo" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/ahu-w.png" width="28px" style="margin-right:2px"/> <span class="Txt">Tomo Therapy</span></a>
                                        </li>
                                         <li>
                                          <a href="<?php echo site_url('Admin/Home/aircondition_apollo/')?>#cancr" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/ahu-w.png" width="22px"/> <span class="Txt">Cancer Block</span></a>
                                          </li>
                                          <li>
                                          <a href="<?php echo site_url('Admin/Home/aircondition_apollo/')?>#opl" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/ahu-w.png" width="22px"/> <span class="Txt">Operation Theater</span></a>
                                          </li>
                                    </ul>
                                </li>
                                <li>
                                    <a class="Lnk Arr Slct" href="#" onclick="menushow(89)" id="cat558"><img src="<?php echo site_url() ?>asset/admin/images/Boilers.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Boilers</span></a>
                                    <ul class="ScndLvl" id="subcat89" style="display: none;">
                                         
                                         <li>
                                            <a href="<?php echo site_url('Admin/Home/boilers/')?>#boilers" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/Boilers.png" width="28px" style="margin-right:2px"/> <span class="Txt">Boiler</span></a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                
                    <li>
                        <a href="<?php echo site_url('Admin/Home/all_reports_apollo') ?>" class="Lnk Arr" id="reportss"><img src="<?php echo site_url() ?>asset/admin/img/reports-img.png" width="20px"/> <span class="Txt">Reports</span></a>
                    </li>
                    
                </ul>
            </div>
        </div>
        