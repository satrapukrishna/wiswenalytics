<div  class="text-head"> Ventilation Fans Running Hours Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
	 <thead>
                            <tr style="font-weight: bold;">
                                <th>Sno</th>
                                <th>Name</th>
                                <th>Floor</th>
                                <th>Date/Hours</th>
                                <th>Running Hours</th>                                
                            </tr>
                        </thead>
						
							
						<tbody>
							<tr>
							<td align='center'>1</td>
							<td align='center'>Ventilation Fan 01</td>
							<td align='center'>Floor1</td>
							<td align='center'>2020-11-01</td>
							<td align='center'>12 Hours 45 Min. </td>							
							</tr>
							<tr>
							<td align='center'>2</td>
							<td align='center'>Ventilation Fan 01</td>
							<td align='center'>Floor1</td>
							<td align='center'>2020-11-02</td>
							<td align='center'>11 Hours 11 Min.</td>							
							</tr>
							<tr>
							<td align='center'>3</td>
							<td align='center'>Ventilation Fan 01</td>
							<td align='center'>Floor1</td>
							<td align='center'>2020-11-03</td>
							<td align='center'>10 Hours 11 Min.</td>							
							</tr>
							<tr>
							<td align='center'>4</td>
							<td align='center'>Ventilation Fan 01</td>
							<td align='center'>Floor1</td>
							<td align='center'>2020-11-04</td>
							<td align='center'>8 Hours 55 Min.</td>							
							</tr>
							<tr>
							<td align='center'>5</td>
							<td align='center'>Ventilation Fan 01</td>
							<td align='center'>Floor1</td>
							<td align='center'>2020-11-05</td>
							<td align='center'>11 Hours 10 Min</td>							
							</tr>
							<tr>
							<td align='center'>6</td>
							<td align='center'>Ventilation Fan 01</td>
							<td align='center'>Floor1</td>
							<td align='center'>2020-11-06</td>
							<td align='center'>14 Hours 6 Min</td>							
							</tr>
						
							
						</tbody>
					</table>