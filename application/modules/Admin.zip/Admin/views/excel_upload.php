<html>
<body>
<div id="wrapper">
 <form method="post" action="rainbow_data_upload" enctype="multipart/form-data">
  <input type="file" name="file"/>
  <input type="submit" name="submit_file" value="Submit"/>
 </form>
</div>
</body>
</html>
