<div  class="text-head"> DG Trip Status Report</div>
<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
						<thead>
							<tr style="font-weight: bold;"> 
							<th align='center'>SNo</th>
                            <th align='center'>Date</th>
							<th align='center'>Generator</th> 
							<th align='center'>Floor</th>    
							<th  align='center'>Number Of Trips</th> 
                            
							</tr>
							
							<tr>
							<td align='center' >1</td>
							<td align='center' >01-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >4</td>
                            		
							</tr>
							<tr>
							<td align='center' >2</td>
							<td align='center' >02-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >6</td>
                           							
							</tr>
                            <tr>
							<td align='center' >3</td>
							<td align='center' >03-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >5</td>
                           							
							</tr>
							<tr>
							<td align='center' >4</td>
							<td align='center' >04-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >8</td>
                            							
							</tr>
                            <tr>
							<td align='center' >4</td>
							<td align='center' >05-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >7</td>
                           							
							</tr>
                            </thead>
						<tbody>
							
							
						</tbody>
					</table>
