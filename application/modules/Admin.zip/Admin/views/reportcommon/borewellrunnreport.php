<span class="SctnTtl">Borewell Running Report</span>

<table class="RprtTbl" >
	<thead>
							<tr >
								<th >Sno.</th>								
								<th >Meter</th>
								<th >location</th>
								<th >Date/Hours	</th>
								<th >Running Hours</th>
								<th >Avg Flow Rate</th>
								<th >Present Flow</th>
								<th >% Diffrence</th>
								
							</tr>
						</thead>
						<tbody>
							
								<tr>
								<td >1</td>
								
								<td >Borewell-1</td>
								<td >Tower A</td>
								<td ><?php echo date('d-m-Y') ?></td>
								<td >1 hour 10 mins</td>
								<td >120KL</td>
								<td >100KL</td>
								<td >60</td>
								</tr>
								<tr>
								<td >2</td>
								
								<td >Borewell-1</td>
								<td >Tower A</td>
								<td ><?php echo date('d-m-Y', strtotime( $d . " -1 days")); ?></td>
								<td >0 hour 36 mins</td>
								<td >170KL</td>
								<td >160KL</td>
								<td >70</td>
								</tr><tr>
								<td >3</td>
								
								<td >Borewell-1</td>
								<td >Tower A</td>
								<td ><?php echo date('d-m-Y', strtotime( $d . " -2 days")); ?></td>
								<td >2 hours 8 mins</td>
								<td >150KL</td>
								<td >145KL</td>
								<td >65</td>
								</tr>
								<tr>
								<td >3</td>
								
								<td >Borewell-2</td>
								<td >Tower A</td>
								<td ><?php echo date('d-m-Y') ?></td>
								<td >1 hour 10 mins</td>
								<td >120KL</td>
								<td >100KL</td>
								<td >60</td>
								</tr>
								<tr>
								<td >4</td>
								
								<td >Borewell-2</td>
								<td >Tower A</td>
								<td ><?php echo date('d-m-Y', strtotime( $d . " -1 days")); ?></td>
								<td >0 hour 36 mins</td>
								<td >170KL</td>
								<td >160KL</td>
								<td >70</td>
								</tr><tr>
								<td >3</td>
								
								<td >Borewell-1</td>
								<td >Tower A</td>
								<td ><?php echo date('d-m-Y', strtotime( $d . " -2 days")); ?></td>
								<td >2 hours 8 mins</td>
								<td >150KL</td>
								<td >145KL</td>
								<td >65</td>
								</tr>
								
								
							
						</tbody>
					</table>