<div class="AppMnuHldr">
        <div class="MnuLstHldr">
            <ul class="MnuLst">
                <li>
                    <a href="<?php echo site_url('Admin/Protech/airquality/')?>" class="Lnk Actv">
                        <span class="LnkIcn WISIcn-Menu-Dashboard"></span>
                        <span class="LnkTxt">Dashboard</span>
                    </a>
                </li>
                
               
                
               
                
              
            </ul>
        </div>
    </div>