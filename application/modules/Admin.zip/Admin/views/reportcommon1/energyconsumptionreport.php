<div  class="text-head"> Energy Consumption Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
	<thead>
							<tr style="font-weight: bold;">
								<th class="text-center">Sno.</th>
								<th class="text-center">Date/Hours	</th>
								<th class="text-center">Floor</th>
								<th class="text-center">Meter</th>			
								
								<th class="text-center">Consumption</th>
								
							</tr>
						</thead>
						<tbody>
							
								<tr>
								<td class="text-center">1</td>
								<td class="text-center"><?php echo date('d-m-Y') ?></td>
								<td class="text-center">Floor-1</td>
								<td class="text-center">EM 01 (UPS INCOMER-01)</td>
								
								<td class="text-center">382.0 kWh
								
								</td>
								</tr>
								<tr>
								<td class="text-center">2</td>
								<td class="text-center"><?php echo date('d-m-Y') ?></td>
								<td class="text-center">Floor-1</td>
								<td class="text-center">EM 02 (UPS INCOMER-01)</td>
								
								<td class="text-center">1428.0 kWh
								
								</td>
								</tr><tr>
								<td class="text-center">3</td>
								<td class="text-center"><?php echo date('d-m-Y') ?></td>
								<td class="text-center">Floor-1</td>
								<td class="text-center">EM 01 (RP INCOMER-01)</td>
								
								<td class="text-center">5.0 kWh
								
								</td>
								</tr>
								
								
							
						</tbody>
					</table>