<div  class="text-head"> DG Running Hours Report</div>
<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
						<thead>
							<tr style="font-weight: bold;"> 
							<th align='center'>SNo</th>
                            <th align='center'>Date</th>
							<th align='center'>Generator</th> 
							<th align='center'>Floor</th>    
							<th  align='center'>Running Hours</th> 
                            <th  align='center'>Fuel Consumed(In Ltrs)</th> 
                            <th  align='center'>Economy(Ltrs/Hr)</th> 
                            <th  align='center'>Fuel Added(In Ltrs)</th> 
                            <th  align='center'>Fuel Removed(In Ltrs)</th> 
                            <th  align='center'>Fuel Left(In Ltrs)</th>
							</tr>
							
							<tr>
							<td align='center' >1</td>
							<td align='center' >01-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 0 Mins</td>
                            <td align='center' >0</td>
							<td align='center' >0</td>
							<td align='center' >0</td>
							<td align='center' >0</td>
                            <td align='center' >500</td>							
							</tr>
							<tr>
							<td align='center' >2</td>
							<td align='center' >02-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 20 Mins</td>
                            <td align='center' >10</td>
							<td align='center' >33.3</td>
							<td align='center' >10</td>
							<td align='center' >0</td>
                            <td align='center' >500</td>							
							</tr>
                            <tr>
							<td align='center' >3</td>
							<td align='center' >03-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 30 Mins</td>
                            <td align='center' >15</td>
							<td align='center' >75</td>
							<td align='center' >0</td>
							<td align='center' >0</td>
                            <td align='center' >485</td>							
							</tr>
							<tr>
							<td align='center' >4</td>
							<td align='center' >04-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 0 Mins</td>
                            <td align='center' >0</td>
							<td align='center' >0</td>
							<td align='center' >0</td>
							<td align='center' >0</td>
                            <td align='center' >485</td>							
							</tr>
                            <tr>
							<td align='center' >4</td>
							<td align='center' >05-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 0 Mins</td>
                            <td align='center' >0</td>
							<td align='center' >0</td>
							<td align='center' >15</td>
							<td align='center' >0</td>
                            <td align='center' >500</td>							
							</tr>
                            </thead>
						<tbody>
							
							
						</tbody>
					</table>
