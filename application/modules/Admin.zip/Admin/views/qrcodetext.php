<div class="container" style="margin-top:11px;">
    <div class="row">
      	<div class="col-md-6">

			<h4>How to generate QR Code using Codeigniter</h4>
			<br><br>
			<form action="Qrcontroller/qrcodeGenerator" method="post">
				<div class="form-group">
				    <label for="text">Enter Text For Qr Code Generation:</label>
				    <input type="text" class="form-control" name="qrcode_text">
			  	</div>
			  	<div class="form-group">
				   <button class="btn btn-default">Submit</button>
			  	</div>
			</form>
		</div>
	</div>
</div>				

