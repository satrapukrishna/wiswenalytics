<div  class="text-head"> Water Meter Consumption Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
	 <thead>
                            <tr style="font-weight: bold;">
                                <th>Sno</th>
                                <th>Meter</th>
                                <th>Floor</th>
                                <th>Date/Hours</th>
                                <th>Consumption(Ltr)</th> 
                                <th>Percentage Difference to Average</th>                                
                            </tr>
                        </thead>
						
							
						<tbody>
							
							<tr>
							    <td>1</td>
							    <td>Water Meter1</td>
							    <td>02-12-2020</td>
							    <td>Location1</td>
							    <td>410</td>
							    <td>10%</td>
							  </tr>
							  <tr>
							    <td>2</td>
							    <td>Water Meter2</td>
							    <td>02-12-2020</td>
							    <td>Location1</td>
							    <td>350</td>
							    <td>1%</td>
							  </tr>
							 <tr>
							    <td>3</td>
							    <td>Water Meter3</td>
							    <td>02-12-2020</td>
							    <td>Location1</td>
							    <td>350</td>
							    <td>2%</td>
							  </tr>
							  <tr>
							    <td>4</td>
							    <td>Water Meter4</td>
							    <td>02-12-2020</td>
							    <td>Location1</td>
							    <td>300</td>
							    <td>1%</td>
							  </tr>
							  <tr>
							    <td>5</td>
							    <td>Water Meter1</td>
							    <td>02-12-2020</td>
							    <td>Location2</td>
							    <td>370</td>
							    <td>5%</td>
							  </tr>
							  <tr>
							    <td>6</td>
							    <td>Water Meter2</td>
							    <td>02-12-2020</td>
							    <td>Location2</td>
							    <td>400</td>
							    <td>3%</td>
							  </tr>
							  <tr>
							    <td>7</td>
							    <td>Water Meter3</td>
							    <td>02-12-2020</td>
							    <td>Location2</td>
							    <td>390</td>
							    <td>5%</td>
							  </tr>
							  <tr>
							    <td colspan="4">Total</td>

							    <td>2750</td>
							    <td>22%</td>
							  </tr>
						
							
						</tbody>
					</table>