<div  class="text-head"> DG Economy Report</div>
<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
						<thead>
							<tr style="font-weight: bold;"> 
							<th align='center'>SNo</th>
                            <th align='center'>Date</th>
							<th align='center'>Generator</th> 
							<th align='center'>Floor</th>    
							<th  align='center'>Running Hours</th> 
                            <th  align='center'>Fuel Consumed(In Ltrs)</th> 
                            <th  align='center'>Economy(Ltrs/Hr)</th> 
                            
							</tr>
							
							<tr>
							<td align='center' >1</td>
							<td align='center' >01-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >4 Hours and 13 Mins	</td>
                            <td align='center' >32.42</td>
							<td align='center' >7.69</td>
														
							</tr>
							<tr>
							<td align='center' >2</td>
							<td align='center' >02-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 0 Mins</td>
                            <td align='center' >0</td>
							<td align='center' >0</td>
														
							</tr>
                            <tr>
							<td align='center' >3</td>
							<td align='center' >03-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >9 Hours and 55 Mins	</td>
                            <td align='center' >88.61</td>
							<td align='center' >8.94</td>
														
							</tr>
							<tr>
							<td align='center' >4</td>
							<td align='center' >04-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 17 Mins	</td>
                            <td align='center' >3.22</td>
							<td align='center' >11.36</td>
														
							</tr>
                            <tr>
							<td align='center' >5</td>
							<td align='center' >05-10-2020</td>
							<td align='center' >Diesel Generator</td>
							<td align='center' >Floor1</td>
							<td align='center' >0 Hours and 38 Mins	</td>
                            <td align='center' >5.95</td>
							<td align='center' >9.39</td>
														
							</tr>
                            </thead>
						<tbody>
							
							
						</tbody>
					</table>
