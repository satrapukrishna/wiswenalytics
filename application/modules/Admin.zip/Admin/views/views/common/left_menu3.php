<div id="DshbrdLft" class="DshBrdLnk">
            <div class="BrndHldr">
            
                <a href="<?php echo site_url('Admin/Home/')?>" ><span class="BrndNm"><?php echo $this->session->userdata('client_name')?></span></a>
            </div>
            <div class="DshBrdLnkCntr" id="root" data-simplebar>
                <ul class="LnkHldr FrstLvl">
                    
                    
                        <li>
                        <a class="Lnk Arr Slct" href="#" onclick="menushow(555)" id="cat555"><img src="<?php echo site_url() ?>asset/demoforall/Images/Water-Tank-W.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Water</span></a>
                        <ul class="ScndLvl" id="subcat555" style="display: none;">                          
                        
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#water" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/water_level_menu.png" width="22px"/> <span class="Txt">Water Level</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#line" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/line-w.png" width="22px"/> <span class="Txt">Line Pressure</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#motor" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/motor-w.png" width="22px"/> <span class="Txt">Motor Running</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#water_meter" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/Flow-Meter-W.png" width="22px"/> <span class="Txt">Water Meter</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#fire" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/Fire-Pump-W.png" width="22px"/> <span class="Txt">Fire Pump</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#hydro1" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/HydroPnematicSystem.png" width="22px"/> <span class="Txt">Hydro Pnematic System</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#stp" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/STP.png" width="22px"/> <span class="Txt">STP</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#boilers" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/Boilers.png" width="22px"/> <span class="Txt">Boilers</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/water/')?>#hot_water" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/HotWaterTanks.png" width="22px"/> <span class="Txt">Hotwater Tanks</span></a>
                            </li>
                            
                        </ul>
                        </li> 
                        <li>
                        <a class="Lnk Arr Slct" href="#" onclick="menushow(556)" id="cat556"><img src="<?php echo site_url() ?>asset/demoforall/Images/energy-w.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Energy</span></a>
                        <ul class="ScndLvl" id="subcat556" style="display: none;">                          
                        
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#energy" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/Electric-Meter-W.png" width="22px"/> <span class="Txt">Energy Meter</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#btu" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/btu-w.png" width="22px"/> <span class="Txt">BTU</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#dg" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/DG.png" width="22px"/> <span class="Txt">DG</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#upss" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/ups_menu.png" width="22px"/> <span class="Txt">UPS</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#lpg" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/LPG-W.png" width="22px"/> <span class="Txt">LPG</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#trip" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/TripStatus.png" width="22px"/> <span class="Txt">Trip Status</span></a>
                            </li>
                             <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#diesel_tank" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/DieselTank.png" width="22px"/> <span class="Txt">Diesel Tank</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/energy/')?>#diesel_meter" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/DieselMeter.png" width="22px"/> <span class="Txt">Diesel Meters</span></a>
                            </li>
                            <!--  <li>
                                <a href="<?php //echo site_url('Admin/Home/energy/')?>#trip" class="Lnk"><img src="<?php //echo site_url() ?>asset/admin/images/ARD.png" width="22px"/> <span class="Txt">ARD</span></a>
                            </li> -->
                            
                        </ul>
                        </li>
                        <!-- <li> -->
                            <!-- <a class="Lnk Arr Slct" href="#" onclick="menushow(558)" id="cat557"><img src="<?php //echo site_url() ?>asset/demoforall/Images/air_menu.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Air</span></a> -->
                             <!-- <ul class="ScndLvl" id="subcat558" style="display: none;"> -->
                                <li>
                                    <a class="Lnk Arr Slct" href="#" onclick="menushow(559)" id="cat558"><img src="<?php echo site_url() ?>asset/demoforall/Images/air_menu.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Air Conditioning</span></a>
                                    <ul class="ScndLvl" id="subcat559" style="display: none;">
                                         <li>
                                         <a href="<?php echo site_url('Admin/Home/aircondition/')?>#hvac" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/ahu-w.png" width="35px" style="margin-right:0px"/> <span class="Txt">AHU</span></a>
                                         </li>
                                         <li>
                                            <a href="<?php echo site_url('Admin/Home/aircondition/')?>#div7" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/Chillers.png" width="28px" style="margin-right:2px"/> <span class="Txt">Chiller</span></a>
                                        </li>
                                         <li>
                                          <a href="<?php echo site_url('Admin/Home/aircondition/')?>#div8" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/cooling-w.png" width="22px"/> <span class="Txt">Cooling Tower</span></a>
                                          </li>
                                    </ul>
                                </li>
                                <li>
                                    <a class="Lnk Arr Slct" href="#" onclick="menushow(560)" id="cat560"><img src="<?php echo site_url() ?>asset/admin/images/AirQuality.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Air Quality</span></a>
                                     <ul class="ScndLvl" id="subcat560" style="display: none;">
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/airquality/')?>#airqua" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/IndoorAirQuality.png" width="22px"/> <span class="Txt">Indoor Air Quality </span></a>
                                        </li>
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/airquality/')?>#toilet" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/ToiletExhaust.png" width="22px"/> <span class="Txt">Toilet Exhaust </span></a>
                                        </li>
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/airquality/')?>#ventilation" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/VentilationFan.png" width="22px"/> <span class="Txt">Ventilation Fans</span></a>
                                        </li>
                                     </ul>
                                <!-- </li> -->

                             <!-- </ul> -->

                        </li>
                         <li>
                                    <a class="Lnk Arr Slct" href="#" onclick="menushow(570)" id="cat558"><img src="<?php echo site_url() ?>asset/admin/images/SoftIntegration.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Soft Integration</span></a>
                                     <ul class="ScndLvl" id="subcat570" style="display: none;">
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/soft_integration/')?>#lifts" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/Lifts.png" width="22px"/> <span class="Txt">Lifts </span></a>
                                        </li>
                                        <li>
                                             <a href="<?php echo site_url('Admin/Home/soft_integration/')?>#" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/DG.png" width="22px"/> <span class="Txt">DG </span></a>
                                        </li>
                                        <li>
                                             <a href="<?php echo site_url('Admin/Home/soft_integration/')?>#" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/Invertor.png" width="22px"/> <span class="Txt">Invertor </span></a>
                                        </li>
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/soft_integration/')?>#" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/Chillers.png" width="22px"/> <span class="Txt">Chillers </span></a>
                                        </li>
                                        <li>
                                             <a href="<?php echo site_url('Admin/Home/soft_integration/')?>#" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/FireAlarm.png" width="22px"/> <span class="Txt">Fire Alarm System </span></a>
                                        </li>
                                        
                                     </ul>
                                <!-- </li> -->

                             <!-- </ul> -->

                        </li>
                         <li>
                                    <a class="Lnk Arr Slct" href="#" onclick="menushow(571)" id="cat558"><img src="<?php echo site_url() ?>asset/admin/images/SpeacilizedSolutions.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Specialized Solution</span></a>
                                     <ul class="ScndLvl" id="subcat571" style="display: none;">
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/specialized/')?>#washroom" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/WashrromMonitoring.png" width="22px"/> <span class="Txt">Washroom Monitoring </span></a>
                                        </li>
                                        <li>
                                             <a href="<?php echo site_url('Admin/Home/specialized/')?>#cold_room" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/ColdRoom.png" width="22px"/> <span class="Txt">Cold Room </span></a>
                                        </li>
                                        <li>
                                             <a href="<?php echo site_url('Admin/Home/specialized/')?>#floor_wetness" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/FloorWet.png" width="22px"/> <span class="Txt">Floor Wetness </span></a>
                                        </li>
                                         <li>
                                             <a href="<?php echo site_url('Admin/Home/specialized/')?>#door_open" class="Lnk"><img src="<?php echo site_url() ?>asset/admin/images/WashrromMonitoring.png" width="22px"/> <span class="Txt">Door -Open/Close </span></a>
                                        </li>
                                        
                                     </ul>
                                <!-- </li> -->

                             <!-- </ul> -->

                        </li>
                       <!--  <li>
                        <a class="Lnk Arr Slct" href="#" onclick="menushow(557)" id="cat557"><img src="<?php echo site_url() ?>asset/demoforall/Images/air_menu.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Air</span></a>
                        <ul class="ScndLvl" id="subcat557" style="display: none;">                          

                            <li>
                                <a href="<?php echo site_url('Admin/Home/air/')?>#hvac" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/ahu-w.png" width="35px" style="margin-right:0px"/> <span class="Txt">AHU</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/air/')?>#airqua" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/air_menu.png" width="22px"/> <span class="Txt">Indoor Air Quality </span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/air/')?>#div7" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/chiller-w.png" width="28px" style="margin-right:2px"/> <span class="Txt">Chiller</span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('Admin/Home/air/')?>#div8" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/cooling-w.png" width="22px"/> <span class="Txt">Cooling Tower</span></a>
                            </li>
                            
                            
                            
                        </ul>
                        </li> -->
                         <?php /*
                    <li>
                        <a href="" class="Lnk Arr" id="reports"><img src="<?php echo site_url() ?>asset/admin/img/reports-img.png" width="20px"/> <span class="Txt">Reports</span></a>
                        <ul class="ScndLvl" id="reportsmenu" style="display:none">
                            
                           <?php 
                            $devices1=$this->Api_data_model->get_devices('');
                            foreach($devices1 as $dev1){
                                ?>
                                <li><a href="" class="Lnk Arr" onclick="reports2(<?php echo $dev1['device_id']?>);return false;"><span class="Txt"><?php echo ucwords(strtolower($dev1['device_name']))?> Reports</span></a>
                                    <ul class="ThrdLvl" id="subreports<?php echo $dev1['device_id']?>" style="display:none">
                                    <li>
                                        <a href="<?php echo site_url('Admin/Home/reports/' . $dev1['device_id']).'/Running_hours' ?>" class="Lnk"><span class="Txt">Running Hours Report</span></a>
                                    </li>
                                    <li>
                                        
                                        <a href="<?php echo site_url('Admin/Home/reports/' . $dev1['device_id']).'/Graph' ?>" class="Lnk"><span class="Txt"><?php echo $dev1['device_name']?> GRAPH REPORT</span></a>
                                    </li>
                                    </ul>
                                </li>
                                <?php
                            }
                            ?>
                        
                            <li><a href="" class="Lnk Arr" id="firepump"><span class="Txt">Energy Meter Reports</span></a>
                                    <ul class="ThrdLvl" id="subfirepump" style="display:none">
                                    <li>
                                        <a href="<?php echo site_url('Admin/Home/energy_reports') ?>" class="Lnk"><span class="Txt">Consumption Report</span></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url('Admin/Home/energy_graph_reports') ?>" class="Lnk"><span class="Txt">Consumption Graph Report</span></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url('Admin/Home/energy_powerfctr_reports') ?>" class="Lnk"><span class="Txt">Power Factor</span></a>
                                    </li>
                                    
                                    </ul>
                            </li>
                            <li><a href="" class="Lnk Arr" id="firepump1"><span class="Txt">BTU Meter Reports</span></a>
                                    <ul class="ThrdLvl" id="subfirepump1" style="display:none">
                                    <li>
                                        <a href="<?php echo site_url('Admin/Home/btu_reports') ?>" class="Lnk"><span class="Txt">Consumption Report</span></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url('Admin/Home/btu_reports') ?>" class="Lnk"><span class="Txt">Graph Report</span></a>
                                    </li>
                                    
                                    </ul>
                            </li>
                            
                        </ul>
                    </li> 
                    */?>
                    <li>
                        <a href="<?php echo site_url('Admin/Home/all_reports') ?>" class="Lnk Arr" id="reportss"><img src="<?php echo site_url() ?>asset/admin/img/reports-img.png" width="20px"/> <span class="Txt">Reports</span></a>
                    </li>
                    
                </ul>
            </div>
        </div>
        