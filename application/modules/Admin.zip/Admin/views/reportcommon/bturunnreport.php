<div  class="text-head"> BTU Running Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
	<thead>
							<tr style="font-weight: bold;">
								<th class="text-center">Sno.</th>
								<th class="text-center">Floor</th>
								<th class="text-center">Meter</th>
								
								<th class="text-center">Date/Hours	</th>
								<th class="text-center">Energy Consumption
</th>
								
							</tr>
						</thead>
						<tbody>
							
								<tr>
								<td class="text-center">1</td>
								
								<td class="text-center">Floor-1</td>
								<td class="text-center">BTU01</td>
								<td class="text-center"><?php echo date('d-m-Y') ?></td>
								<td class="text-center">0.0 kWh
								
								</td>
								</tr>
								<tr>
								<td class="text-center">2</td>
								
								<td class="text-center">Floor-1</td>
								<td class="text-center">BTU02</td>
								<td class="text-center"><?php echo date('d-m-Y') ?></td>
								<td class="text-center">0.0 kWh
								
								</td>
								</tr><tr>
								<td class="text-center">3</td>
								
								<td class="text-center">Floor-1</td>
								<td class="text-center">BTU03</td>
								<td class="text-center"><?php echo date('d-m-Y') ?></td>
								<td class="text-center">5.0 kWh
								
								</td>
								</tr>
								
								
							
						</tbody>
					</table>