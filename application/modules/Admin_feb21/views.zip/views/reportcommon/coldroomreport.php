<div  class="text-head"> Cold Room  Report</div>

<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px;display: none;">
	 <thead>
                            <tr style="font-weight: bold;">
                                <th>Sno</th>
                                <th>Location</th>
                   
                                <th>Date/Hours</th>
                                <th>No.of Time Door Open</th>
                                <th>Door Open Time</th>                                
                            </tr>
                        </thead>
						
							
						<tbody>
							<tr>
							<td align='center'>1</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>00:00:00 To 01:00:00</td>
							<td align='center'>2</td>
							<td align='center'>10 Min</td>							
							</tr>
							<tr>
							<td align='center'>2</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>01:00:00 To 02:00:00</td>
							<td align='center'>3</td>
							<td align='center'>5 Min</td>							
							</tr>
							<tr>
							<td align='center'>3</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>02:00:00 To 03:00:00</td>
							<td align='center'>1</td>
							<td align='center'>6 Min</td>							
							</tr>
							<tr>
							<td align='center'>4</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>03:00:00 To 04:00:00</td>
							<td align='center'>5</td>
							<td align='center'>15 Min</td>							
							</tr>
							<tr>
							<td align='center'>5</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>04:00:00 To 05:00:00</td>
							<td align='center'>3</td>
							<td align='center'>5 Min</td>							
							</tr>
							<tr>
							<td align='center'>6</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>05:00:00 To 06:00:00</td>
							<td align='center'>1</td>
							<td align='center'>10 Min</td>							
							</tr>
							<tr>
							<td align='center'>7</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>06:00:00 To 07:00:00</td>
							<td align='center'>4</td>
							<td align='center'>20 Min</td>							
							</tr>
							<tr>
							<td align='center'>8</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>07:00:00 To 08:00:00</td>
							<td align='center'>3</td>
							<td align='center'>10 Min</td>							
							</tr>
							<tr>
							<td align='center' colspan="3">Total</td>
							<td align='center'>22</td>
							
							<td align='center'>81 Min</td>
														
							</tr>
						
							
						</tbody>
					</table>


					<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
	 <thead>
                            <tr style="font-weight: bold;">
                                <th>Sno</th>
                                <th>Location</th>
                   
                                <th>Date/Hours</th>
                                <th>No.of Time Door Open</th>
                                <th>Door Open Time</th>                                
                            </tr>
                        </thead>
						
							
						<tbody>
							<tr>
							<td align='center'>1</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>01-12-2020</td>
							<td align='center'>30</td>
							<td align='center'>50 Min</td>							
							</tr>
							<tr>
							<td align='center'>2</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>02-12-2020</td>
							<td align='center'>23</td>
							<td align='center'>44 Min</td>							
							</tr>
							<tr>
							<td align='center'>3</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>03-12-2020</td>
							<td align='center'>33</td>
							<td align='center'>55 Min</td>							
							</tr>
							<tr>
							<td align='center'>4</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>04-12-2020</td>
							<td align='center'>13</td>
							<td align='center'>33 Min</td>							
							</tr>
							<tr>
							<td align='center'>5</td>
							<td align='center'>Room 01</td>
							
							<td align='center'>05-12-2020</td>
							<td align='center'>22</td>
							<td align='center'>66 Min</td>							
							</tr>
							<tr>
							<td align='center' colspan="3">Total</td>
							<td align='center'>55</td>
							
							<td align='center'>381 Min</td>
														
							</tr>
						
							
						</tbody>
					</table>