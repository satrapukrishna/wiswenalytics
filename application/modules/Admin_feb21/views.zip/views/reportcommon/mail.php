<?php 
         

            $msg_data =   "<b style='font-size: 13px;font-family: arial; line-height: 25px;'>Hi,</b><br>";
            $msg_data.= "<b style='font-size: 13px;font-family: arial; line-height: 25px;'>Date: 02-12-2020 </b><br>";
            $msg_data.= "<b style='font-size: 13px;font-family: arial; line-height: 25px;'>Client Name : 
            Demo Client</b>";
            $msg_data.= '<table  bgcolor="#fffff0" style="width:100%;border:1px solid #ccc"><tr>
    <th style="background-color: #378fa7; color: white;font-size: 13px;font-family: arial;font-weight: bold;">SNo</th>
    <th style="background-color: #378fa7; color: white;font-size: 13px;font-family: arial;font-weight: bold;">Meter</th> 
    <th style="background-color: #378fa7; color: white;font-size: 13px;font-family: arial;font-weight: bold;">Date</th>
    <th style="background-color: #378fa7; color: white;font-size: 13px;font-family: arial;font-weight: bold;">Location</th>
    <th style="background-color: #378fa7; color: white;font-size: 13px;font-family: arial;font-weight: bold;">Consumption(Ltr)</th>
    <th style="background-color: #378fa7; color: white;font-size: 13px;font-family: arial;font-weight: bold;">Percentage Difference to Average</th>
  </tr>
  <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">500</td>
    <td align="center" style="background-color:#8ce6a4;border:1px solid #ccc">5%</td>
  </tr>
  <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">2</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter2</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">350</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#ebafa9;" >1%</td>
  </tr>
 <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">3</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter3</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">350</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#ebeb98;">2%</td>
  </tr>
  <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">4</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter4</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">350</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#8ce6a4;">1%</td>
  </tr>
  <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">5</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter1</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location2</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">500</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#ebafa9;">5%</td>
  </tr>
  <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">6</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter2</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location2</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">400</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#8ce6a4;">3%</td>
  </tr>
  <tr>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">7</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Water Meter3</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">02-12-2020</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Location2</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">500</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#ebafa9;">5%</td>
  </tr>
  <tr>
    <td colspan="4" align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">Total</td>

    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc">2750</td>
    <td align="center" style="font-family:arial;
    font-size: 12px;line-height: 25px;;border:1px solid #ccc;background-color:#ebafa9;">22%</td>
  </tr>
</table>';
          // $j=1;
          //   for ($i=0; $i < count($dataTemp); $i++) { 
          //      $msg_data.= "<tr style='background-color: #e6f1f5;'><td align='center' style='font-family:arial;font-size: 12px;line-height: 25px;'>".$j."</td><td align='center' style='font-family:arial;font-size: 12px;line-height: 25px;'>".$dataTemp[$i]['Time']."</td><td align='center' style='font-family:arial;font-size: 12px;line-height: 25px;'>".$dataTemp[$i]['min']."</td><td align='center' style='font-family:arial;font-size: 12px;line-height: 25px;'>".$dataTemp[$i]['max']."</td><td align='center' style='font-family:arial;font-size: 12px;line-height: 25px;'>".$dataHumidity[$i]['min']."</td><td align='center' style='font-family:arial;font-size: 12px;line-height: 25px;'>".$dataHumidity[$i]['max']."</td></tr>";
          //      $j++;
          //   }
         
            
           $msg_data.= '</table><br>Thanks and Regards,<br />Wenalytics Team<br />';
            echo $msg_data;
            $config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'ssl://smtp.googlemail.com',
        'smtp_port' => 465,
       // 'smtp_user' => 'ChekhraApp@gmail.com',
         'smtp_user' => 'reportdemo21@gmail.com',
        //'smtp_pass' => 'Chk@1234',
         'smtp_pass' => 'report@12345678',
        'mailtype'  => 'html', 
        'charset' => 'utf-8',
        'wordwrap' => TRUE

    );
   echo $msg_data;
    $this->load->library('email');
    $this->email->initialize($config);   
    $this->email->set_newline("\r\n"); 
    $this->email->set_mailtype("html");   
    $this->email->from('reports@wenalytics.com', 'Wenalytics');
    
   $list = array('krishna3175@gmail.com' );
    $this->email->to($list);
    $this->email->subject('Daily Mail');
    $this->email->message($msg_data);
    $this->email->send();

    
    
    
    
          
    ?>