<div class="AppMnuHldr">
        <div class="MnuLstHldr">
            <ul class="MnuLst">
                <li>
                    <a href="<?php echo site_url('Admin/Home/airquality/')?>" class="Lnk Actv">
                        <span class="LnkIcn WISIcn-Menu-Dashboard"></span>
                        <span class="LnkTxt">Dashboard</span>
                    </a>
                </li>
                
                <li>
                    <span class="Lnk">
                        <span class="LnkIcn WISIcn-Menu-ComplaintsAdmin"></span>
                        <span class="LnkTxt">Air Quality<span class="Arrw WISIcn-ArrowRight"></span></span>
                    </span>
                    <ul class="SbMnu">
                        <li>
                            <span class="Lnk">
                            
                            <a href="<?php echo site_url('Admin/Home/airquality/')?>#airqua" class="Lnk"> <span class="Txt">Indoor Air Quality </span></a>
                            </span>
                            
                        </li>
                       
                    </ul>
                </li>
                
               
                
                <li>
                    <a href="<?php echo site_url('Admin/Home/protech_reports') ?>" class="Lnk">
                        <span class="LnkIcn WISIcn-Menu-Reports"></span>
                        <span class="LnkTxt">Reports</span>
                        
                    </a>
                </li>
            </ul>
        </div>
    </div>