consumption 420

avg 420
350
400



1)Boilers
working->on/off
2)water tanks
curr volume->total volume
remove more details
3)wahroom add feedback
\4)cold room remove flors
 working>door open/close
 avg temp->Temp mantained
 remove -degree
 avg energy cons->number of times door opened
 avg door usage->door open time
 5)floor wetness
 floor1->basement 01
 stp room,dg room,hydro numatic room
 working->dry/wet
 wet->priority,high
 dry->na,na

 6)door open/close

 same as floor wet




 12-15-2020 changes

 1)sevage treat plant

  remove down two elemnts
  add 3 and 2
  2) toilet ecaxt
  same
  3)ARD
  add ard to lifts as button red,green
  4)trip status
  

  18-12-2020

  1)diesel tank
   selected color chsnge
    remove more details
    2)floor->inflow,out flow
    3)ups icon

   
   





done

 5)toilet exast
    open->on off
 4)iaq
    different graph
    co2 color chsange

    6)floor wetness icon chsange

    dry wet reverse
    7)remove more details
    remove basements


   door open->red
   issue raised->door open since





   reports

   1)washroom
   2)



energy

diesel meter remove infloe,outflow
change 101,....

2)Trip Sataus like fiere pump
asset tripstatus

dg1  yes
dg2  no
hydronem1 yes
hydro2 yes

mcb1 yes
mcb2 no
mcb3 no
mcb4 no

ventilation panel1
ventilation panel2
ups1
ups2

3)



12-21-2020

1)savage t p
all in one place
2)ventilation fans
remove auto/manu from header
trip statu->ok->green/trip->red
CO->remove image
3)AHU
remove auto/manual

remove header part


on            cooling->icon  set temp->icon
returnairtemp  actuaterlevel->no icon vfd->no icon

air flow->

supplyair retrnair deltaT

water flow->

same as air flow

rename addition details->filter details

filterpressur,blockage

22-12-2020

toilet exaust->running hours
ventilation fans->running hours,co level graph

swt 8deg
rwt 12deg
remove heat



1)chiller

on/off status   runninghrs  set point



inlet water temp / outlet water temp /deltaT


compressor1,2 same as design


2)cooling Tower same as chiller










