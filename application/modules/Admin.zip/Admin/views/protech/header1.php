<div class="AppHeader">
        <div class="AppMnuTtlHldr">
            <div class="TtlHldr">
                <div class="ClntLgoHldr">
                    <img src="<?php echo base_url(); ?>asset/protechs/Images/protech.png" class="Lgo" />
                </div>
            </div>
        </div>
        <!-- <div class="AppUsrCntrlHldr">
            <ul class="UsrNav">
                <li>
                    <a href="#" class="NavLnk WISIcn-Notification"></a>
                </li>
                <li>
                    <a href="#" class="NavLnk WISIcn-Help"></a>
                </li>
                <li>
                    <div class="UsrDvHldr">
                        <div class="UsrDtls">
                            <div class="PrflNmeHldr">
                                <span class="Nme">NH Admin</span>
                            </div>
                           
                        </div>
                    </div>
                    
                </li>
            </ul>
        </div> -->
    </div>