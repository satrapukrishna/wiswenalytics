<div id="DshbrdLft" class="DshBrdLnk">
            
            <div class="DshBrdLnkCntr" id="root" data-simplebar>
                <ul class="LnkHldr FrstLvl">
                    
                    
                        <li>
                        <a class="Lnk Arr Slct" href="#" onclick="menushow(555)" id="cat555"><img src="<?php echo site_url() ?>asset/demoforall/Images/Water-Tank-W.png" width="20px"/> <span id="dsh" class="Lnk Arr Slct Dshbrd">Water Quality</span></a>
                        <ul class="ScndLvl" id="subcat555" style="display: none;">                          
                        
                            
                            <li>
                                <a href="<?php echo site_url('Admin/Home/waterQuality/')?>#fire" class="Lnk"><img src="<?php echo site_url() ?>asset/demoforall/Images/water_level_menu.png" width="22px"/> <span class="Txt">Water quality</span></a>
                            </li>
                            
                            
                        </ul>
                        </li> 
                       
                       
                    <li>
                        <a href="<?php echo site_url('Admin/Home/all_reports_fire') ?>" class="Lnk Arr" id="reportss"><img src="<?php echo site_url() ?>asset/admin/img/reports-img.png" width="20px"/> <span class="Txt">Reports</span></a>
                    </li>
                    
                </ul>
            </div>
        </div>
        