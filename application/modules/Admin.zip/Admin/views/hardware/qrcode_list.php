﻿<?php //print_r($hardwares);die(); ?>
<html>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">


   
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
    <!-- Main content -->
    <section class="content">


                    <div class="panel panel-default">


                        <input type="hidden" id="page" value="hardware" />


                        <div class="panel-heading"> 


                            <h3 class="panel-title">Hardwares QRCode List</h3>


                            <div class="col-md-2 col-md-offset-10">


                            </div>


                        </div>


                        <div class="panel-body">


                            <div class="col-md-12">


                                <div>




                                </div>
								<br><br>

								<div class="table-responsive" >
                                <table class="table table-striped" id="printableTable">


                                    <thead>


                                        <tr>


                                            <th></th>
                                            
                                            
										
                                        </tr>
                                    </thead>
                                    <tbody>

                                                <tr >


                                                    


                                                 
                                                   
                                                    <td><img src="http://wenalytics.in/asset/admin/hardware_qrcodes/site_assessment_qrcode.png" width="150" /></td>
													


                                                     


                                                </tr>



                                    </tbody>


                                </table>


                            </div>
                            <!-- <iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe> -->
                            </div>


                            


                        </div>


                    </div>
					


                </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<style>.btn-xs{padding:4px}
th{font-size: 14px;}

@media print {
  * {
    display: none;
  }
  #printableTable {
    display: block;
  }
}</style>
<script>
   

	
</script>
</body>
</html>
