<div  class="text-head"> UPS Report</div>
<table cellpadding="10" class="table table-condensed" style="background:#fff;padding:10px">
						<thead>
							<tr style="font-weight: bold;"> 
							<th align='center'>SNo</th>
                            <th align='center'>Date</th>
							<th align='center'>UPS</th>    
							<th align='center'>Floor</th>
                            <th  align='center'>Running Hours</th> 
                           
							</tr>
							
							<tr>
							<td align='center' >1</td>
							<td align='center' >01-10-2020</td>
							<td align='center' >UPS1</td>
							<td align='center' >Floor1</td>
							<td align='center' >0</td>

                            						
							</tr>
							<tr>
							<td align='center' >2</td>
							<td align='center' >02-10-2020</td>
							<td align='center' >UPS1</td>
							<td align='center' >Floor1</td>
							<td align='center' >0</td>
							
                            							
							</tr>
                            <tr>
							<td align='center' >3</td>
							<td align='center' >03-10-2020</td>
							<td align='center' >UPS1</td>
							<td align='center' >Floor1</td>
							<td align='center' >0</td>
							
                          						
							</tr>
							<tr>
							<td align='center' >4</td>
							<td align='center' >04-10-2020</td>
							<td align='center' >UPS1</td>
							<td align='center' >Floor1</td>
							<td align='center' >0</td>
														
							</tr>
                            <tr>
							<td align='center' >5</td>
							<td align='center' >05-10-2020</td>
							<td align='center' >UPS1</td>
							<td align='center' >Floor1</td>
							<td align='center' >0</td>
														
							</tr>
                            </thead>
						<tbody>
							
							
						</tbody>
					</table>