<span class="SctnTtl">Water Level Report</span>
<table class="RprtTbl">
	<thead>
		<tr>
			<th rowspan="2" >S. No.</th>								
			<th >Location</th>
			<th >Date/Hours	</th>
			<th colspan="3">Inlet</th>
			<th colspan="4">Underground Sump Water Volume(Lts)</th>
			<th colspan="4">Overhead Tank Water Volume(Lts)</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<th>Meter</th>
			<th>Water Inflow</th>
			<th>Flow Rate</th>
			<th>Fire Tank</th>
			<th>Raw Water Tank</th>
			<th>Soft Water Tank</th>
			<th>Garden Water Tank</th>
			<th>Fire Tank</th>
			<th>Raw Water Tank</th>
			<th>Soft Water Tank</th>
			<th>Garden Water Tank</th>
		</tr>
			<tr>
			<td>1</td>
			<td>Tower A</td>
			<td><?php echo date('d-m-Y') ?></td>
			<td>Borewell-1</td>
			<td>1000Kl</td>
			<td>500Kl</td>
			<td>8000KL</td>
			<td>7000KL</td>
			<td>5000KL</td>
			<td>6000KL</td>
			<td>8000KL</td>
			<td>7000KL</td>
			<td>5000KL</td>
			<td>6000KL</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Tower B</td>
			<td><?php echo date('d-m-Y') ?></td>
			<td>Borewell-1</td>
			<td>1000Kl</td>
			<td>500Kl</td>
			<td>8000KL</td>
			<td>7000KL</td>
			<td>5000KL</td>
			<td>6000KL</td>
			<td>8000KL</td>
			<td>7000KL</td>
			<td>5000KL</td>
			<td>6000KL</td>
		</tr>
	</tbody>
</table>